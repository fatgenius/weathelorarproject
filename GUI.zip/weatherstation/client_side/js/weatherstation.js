function selectPlot() {
    $.ajax({
        type: 'GET',
        url: '../server_side/' + $('#selected').val() + '.php'
    }).done(function(success) {
        var parsedData = JSON.parse(success);

        google.charts.load('current', {'packages': ['corechart']});
        google.charts.setOnLoadCallback(function() {
            var data = google.visualization.arrayToDataTable(parsedData.values);

            var options = {
                title: parsedData.title,
                curveType: 'function',
                legend: {position: 'bottom'}
            };

            var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
            chart.draw(data, options);
        });
    }).fail(function(error) {
        console.log(error.status + " " + error.statusText);
    });
}