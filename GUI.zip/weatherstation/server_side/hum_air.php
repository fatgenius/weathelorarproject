<?php
$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "weatherstation";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT times, airpressure, humidity FROM datas";
$result = $conn->query($sql);


if ($result->num_rows > 0) 
{
    $values = array();
    $val = array();
    
    array_push($val, "Time");
    array_push($val, "Airpressure");
    array_push($val, "Humidity");
    array_push($values, $val);
    
    while($row = $result->fetch_assoc()) {
        $val = array();
        array_push($val, $row["times"]);
        array_push($val, (float)$row["airpressure"]);
        array_push($val, (int)$row["humidity"]);
        array_push($values, $val);
    }
    $data = (object)array(
        'title' => 'Airpressure and Humidity',
        'values' => $values,
    );
    echo json_encode($data);
} 
else 
{
    echo "0 results";
}

$conn->close();
?>